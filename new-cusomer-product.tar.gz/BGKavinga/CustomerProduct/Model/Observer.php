<?php

/**
 * Class Observer
 * @package ${NAMESPACE}
 */
class BGKavinga_CustomerProduct_Model_Observer
{

    public function createProduct($observer)
    {
        $newCustomer=$observer->getCustomer();
        // create product here and assign to the customer
    }
}