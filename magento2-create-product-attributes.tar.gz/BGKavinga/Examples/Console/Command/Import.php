<?php
/**
 * @category  BGKavinga
 * @package   BGKavinga\Patches
 * @author    B G Kavinga <gihan.seneviratna@gmail.com>
 * @copyright 2017 Kavinga
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace BGKavinga\Examples\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Import extends Command
{
    /**
     * @var \BGKavinga\Examples\Model\ImporterFactory
     */
    private $importerFactory;

    /**
     * Import constructor.
     * @param \BGKavinga\Examples\Model\ImporterFactory $importerFactory
     */
    public function __construct(\BGKavinga\Examples\Model\ImporterFactory $importerFactory)
    {

        $this->importerFactory = $importerFactory;
        parent::__construct();
    }


    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->setName('bgkavinga:import')
            ->setDescription('Import products');
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $importer = $this->importerFactory->create();
        $importer->createAttribute(['myattribute']);
    }
}